package com.javapratice;

import java.util.Date;

public class CurrentDate {
	
	public static void main(String[] args) {
		Date date = new Date();
		 String strDate =  date.toString();
		 System.out.println(strDate);
	}

}
