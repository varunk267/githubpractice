package com.practice;


public class JavaSampleClass {

	public static void main(String[] arr) {
		
		
		for(String str : arr) {
			System.out.println(str);
		}
         
	}

}
