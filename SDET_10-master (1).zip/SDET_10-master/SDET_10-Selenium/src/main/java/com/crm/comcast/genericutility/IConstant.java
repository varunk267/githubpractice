package com.crm.comcast.genericutility;

public interface IConstant {
	
	public String commonDataFilePath ="./testData/commonData.properties";
	public String excelFilePath ="./testdata/TestData.xlsx";
}
